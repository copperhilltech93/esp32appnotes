#ifndef _CONFIG_
#define _CONFIG_

// SPI Signals
#define SPI_MOSI                23
#define SPI_MISO                19
#define SPI_SCK                 18
#define SPI_SS0                 5
#define SPI_SS1                 17

// CAN Controllers
#define CANFD_CONTROLLER_NUM    1    

// Interrupt Input Signals
#define CAN0_INT                26
#define CAN1_INT                34

// Default baud rates
#define CAN_DEFAULT_BAUD	      500000
#define CAN_DEFAULT_FD_RATE     4000000

#endif

// End of File -------------------------------------------------------------
